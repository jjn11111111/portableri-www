# Brick 64 · Chrome extractor · provenance

| Field | Value |
|-------|--------|
| **Upstream** | [D1DX/chatgpt-helper](https://github.com/D1DX/chatgpt-helper) · MIT · Daniel Rudaev @ D1DX |
| **Pinned clone** | `processes/vendor/chatgpt-helper-d1dx` (vendor mirror) |
| **Family fork** | `processes/fork/brick-64-chatgpt-extractor` (this folder) |
| **Fork date** | 2026-10-19 |
| **Reason** | OpenAI account export email not delivered; Lane B local session API export |
| **Changes from upstream** | Manifest name/version label only · no logic edits in v1 fork |

Refresh upstream:

```bash
git -C processes/vendor/chatgpt-helper-d1dx pull
rsync -a --exclude='.git' --exclude='PROVENANCE.md' processes/vendor/chatgpt-helper-d1dx/ processes/fork/brick-64-chatgpt-extractor/
# Re-apply manifest.json family labels if rsync overwrote them.
```

**Law:** Not affiliated with OpenAI. Uses your logged-in browser session only. Comply with OpenAI Terms of Service.
